import UIKit

//O índice é calculado da seguinte maneira: divide-se o peso do paciente pela sua altura elevada ao quadrado. Diz-se que o indivíduo tem peso normal quando o resultado do IMC está entre 18,5 e 24,9.


var peso: Float = 100.30
var altura: Float = 2.10

var imc: Float = peso / (altura * altura)

print("Seu IMC é \(imc)")



// Concatenar String
// 2 Variáveis, Nome e Sobrenome
// Imprimir em padrão BR e US
// Narlei Moreira
// Moreira, Narlei

var nome: String = "Narlei"
var sobrenome: String = "Moreira"


print(nome + " " + sobrenome + ",")

var us = "\(sobrenome), \(nome)"



// Calcular bolas perdidas

var totalBolas: Int = 10
var bolasPerdidas: Int = 2

var totalRestantes: Int = totalBolas - bolasPerdidas
print("Restam: \(totalRestantes)")

bolasPerdidas = 0
totalRestantes = totalBolas - bolasPerdidas

print("Restam: \(totalRestantes)")
